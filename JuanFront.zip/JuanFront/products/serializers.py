from rest_framework import serializers
from .models import Products,UsersProducts


class ProductSerializer(serializers.ModelSerializer):

    class Meta:
        model = Products
        fields = [
            'id',
            'product_name',
            'product_price',
            'product_type',
            'product_stock']


class UsersProductsSerializer(serializers.ModelSerializer):

    class Meta:
        model = UsersProducts
        fields = [
            "id",
            "selling_Date",
            "Products_amount",
            "Client",
            "Product"
        ]
class UsersProductsOutputSerializer(serializers.ModelSerializer):

    class Meta:
        model = UsersProducts
        fields = [
            "id",
            "selling_Date",
            "Products_amount",
            "Client",
            "Product"
        ]

