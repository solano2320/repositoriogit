from django.contrib import admin
from .models import Products,UsersProducts

# Register your models here.
admin.site.register(Products)
admin.site.register(UsersProducts)
