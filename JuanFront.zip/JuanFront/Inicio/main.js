const username = document.getElementById("Username")
const Nombre = document.getElementById("Nombre")
const Apellido = document.getElementById("Apellido")
const Correo = document.getElementById("Correo")

async function obtenerPerfil() {
    try {
        token = localStorage.getItem('token');
        const respuesta = await fetch("http://127.0.0.1:8000/users/my-profile/", {
            method: "GET",
            headers: {
                "Content-type": "application/json",
                "Authorization": `Bearer ${token}`,
            },
        });
        const datos = await respuesta.json();

        // Mostrar los datos en el DOM
        username.innerHTML = datos["username"];
        Nombre.innerHTML = datos["firstName"];
        Apellido.innerHTML = datos["lastName"];
        Correo.innerHTML = datos["email"];
    } catch (error) {
        console.error("Error al obtener el perfil:", error);
    }
}
obtenerPerfil();

async function mostrarcompras() {
    const mostrarDatosBtn = document.getElementById('mostrardatos');
    const datosContainer = document.getElementById('datosContainer');

    mostrarDatosBtn.addEventListener('click', function(event) {
        event.preventDefault(); // Evita que se recargue la página al hacer clic en el enlace
    
        // Hacer visible el contenedor con los datos
        datosContainer.style.display = 'block';
    });

    try {
        const li = document.getElementById("li");
        token = localStorage.getItem('token');
        const respuesta = await fetch("http://127.0.0.1:8000/products/user-producto/", {
            method: "GET",
            headers: {
                "Content-type": "application/json",
                "Authorization": `Bearer ${token}`,
            },
        });
        const datos = await respuesta.json();

        // [
        //     {
        //         "id": 5,
        //         "selling_Date": "2024-11-23",
        //         "Products_amount": 4,
        //         "Client": 79,
        //         "Product": 1
        //     },
        //     {
        //         "id": 6,
        //         "selling_Date": "2024-11-23",
        //         "Products_amount": 4,
        //         "Client": 79,
        //         "Product": 2
        //     }
        // ]
        // Mostrar los datos en el DOM
        datos.forEach(element => {
            const nuevoLi = document.createElement('li');
            li.textContent = element.values;
            li.appendChild(nuevoLi);
        });
    } catch (error) {
        console.error("Error al obtener el perfil:", error);
    }
}
mostrarcompras();
