document.getElementById("form").addEventListener("submit", async (event) => {
    event.preventDefault();

    // Obtener los valores del formulario
    const username = document.getElementById("exampleInputuser").value;
    const email = document.getElementById("exampleInputEmail1").value;
    const password = document.getElementById("exampleInputPassword1").value;
    const firstName = document.getElementById("exampleInputFirst").value;
    const lastName = document.getElementById("exampleInputLast").value;
    const birthDate = document.getElementById("exampleInputBirth").value;
    const biography = document.getElementById("exampleInputBio").value;
    const Rest = document.getElementById("p");

    try{
        console.log("Iniciando solicitud al servidor"); // Antes del fetch
        const response = await fetch("http://127.0.0.1:8000/users/sign-up/", {
            method: "POST",
            headers: {
                "Content-type": "application/json",
            },
            body: JSON.stringify({
                username,
                email,
                password,
                firstName,
                lastName,
                birthDate,
                biography,
            }),
        });
        // const data = await response.json()
    //     .then((response)=>response.json())
    //     .then((data)=>{
    //         // Save JWT to localStorage
    //         localStorage.setItem('token', data.token);
    //         Rest.textContent = 'Login successful!';
    //         Rest.style.color = 'green';
            
    //         // Redirection to client dashboard:
    //         setTimeout(() => {
    //             window.location.href = '/inicio/index.html';
    //         }, 500);
    //     });
    // }catch (error) {
    //     Rest.textContent = 'Network error. Please try again.';
    //     Rest.style.color = 'red';
    // }

        // const data = await response.json();

        if(response.ok){
            localStorage.setItem('token', response.json().token);
            Rest.textContent = 'Login successful!';
            Rest.style.color = 'green';

            window.location.href="/login/index.html"

        }else {
            console.error("Error del servidor:", await response.json());
            alert(`Error: ${data.message || "Algo salió mal"}`);
        }
    } catch (error) {
        console.error("Error en la solicitud:", error);
    }
    
});
    // try {
    //     // Realizar la solicitud a la API
    //     const response = await fetch("http://127.0.0.1:8000/users/sign-up/", {
    //         method: "POST",
    //         headers: {
    //             "Content-Type": "application/json",
    //         },
    //         body: JSON.stringify({
    //             username,
    //             email,
    //             password,
    //             firstName,
    //             lastName,
    //             birthDate,
    //             biography,
    //         }),
    //     });

    //     // Procesar la respuesta
    //     const data = await response.json();

    //     if (response.ok) {
    //         // Almacenar tokens en localStorage
    //         localStorage.setItem("accessToken", data["accessToken"]);
    //         localStorage.setItem("refreshToken", data["refreshToken"]);
    //         console.log("Melo", data);
    //         alert("Registro exitoso");
    //     } else {
    //         console.error("Error del servidor:", data);
    //         alert(`Error: ${data.message || "Algo salió mal"}`);
    //     }
    // } catch (error) {
    //     console.error("Error en la solicitud:", error);
    //     alert("No se pudo conectar al servidor. Intenta de nuevo más tarde.");
    // }

